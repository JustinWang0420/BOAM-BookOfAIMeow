uicoreJsonp([7],{

/***/ 443:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

__webpack_require__(444);

var _splitting = __webpack_require__(445);

var _splitting2 = _interopRequireDefault(_splitting);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

window.addEventListener('DOMContentLoaded', function () {
    var SPLIT = function (_elementorModules$fro) {
        _inherits(SPLIT, _elementorModules$fro);

        function SPLIT() {
            _classCallCheck(this, SPLIT);

            return _possibleConstructorReturn(this, (SPLIT.__proto__ || Object.getPrototypeOf(SPLIT)).apply(this, arguments));
        }

        _createClass(SPLIT, [{
            key: 'bindEvents',
            value: function bindEvents() {
                if (this.getElementSettings('ui_animate_split') === 'ui-split-animate') {
                    this.split();
                    this.animate();
                }
            }
        }, {
            key: 'onElementChange',
            value: function onElementChange(prop) {
                var _this2 = this;

                var is_split = this.getElementSettings('ui_animate_split') === 'ui-split-animate';
                if (prop === 'ui_animate_split' && is_split) {
                    this.unsplit();

                    setTimeout(function () {
                        _this2.split();
                    }, 100);
                }
                if (prop === 'ui_animate_split_by' && is_split) {
                    this.unsplit();

                    setTimeout(function () {
                        _this2.split();
                    }, 100);
                }
                if (is_split) {
                    if (prop.indexOf('ui_animate') !== -1) {
                        this.$element.find('.' + this.get_split(false)).attr('class', this.get_split(false) + '');
                        setTimeout(function () {
                            _this2.animate();
                        }, 150);
                    }
                } else if (prop === 'ui_animate_split') {
                    this.unsplit();
                }
                return;
            }
        }, {
            key: 'split',
            value: function split() {
                var animation = this.getElementSettings('ui_animate_split_style');
                var split = this.get_split();
                var el = this.$element.find('.elementor-widget-container > *:not(style):not(.ui-e-highlight-icon):not(.ui-e-highlight-image)');
                if (el.length == 0) {
                    this.$element.find('.elementor-widget-container').wrapInner('<div class=\"elementor-text-editor\"></div>');
                    el = this.$element.find('.elementor-widget-container > *:not(style)');
                }
                (0, _splitting2.default)({
                    target: el,
                    by: split,
                    key: 'ui-'
                });
                el.addClass('ui-e-' + animation);
            }
        }, {
            key: 'unsplit',
            value: function unsplit() {
                var content = this.$element.find('.elementor-widget-container > *:not(style)')[0];
                var transformedMarkup = content.innerHTML;
                this.$element.find('.elementor-widget-container > *:not(style)')[0].innerHTML = transformedMarkup.replace(/<span class="whitespace">(\s)<\/span>/g, "$1").replace(/<span class="char" data-char="\S+" style="--char-index:\s?\d+;">(\S+)<\/span>/g, "$1").replace(/ aria-hidden="true"/g, "").replace(/<span class="word" data-word="\S+" style="--word-index:\s?\d+;( --line-index:\s?\d+;)?">(\S+)<\/span>/g, "$2");
                content.classList.remove("splitting");
            }
        }, {
            key: 'animate',
            value: function animate() {
                var _this3 = this;

                var $el = jQuery(this.$element);
                var animation = this.getElementSettings('ui_animate_split_style');
                var animateChild = this.$element.find('.' + this.get_split(false));
                var el = this.$element.find('.elementor-widget-container > *:not(style)');
                jQuery(this.$element).addClass('elementor-invisible');
                animateChild.removeClass(animation);
                el.addClass('ui-e-' + animation);

                if (typeof Waypoint != 'undefined') {
                    new Waypoint({
                        element: el,
                        handler: function handler(direction) {
                            $el.css('opacity', 1);
                            setTimeout(function () {
                                el.removeClass('ui-e-' + animation);
                            }, 100);
                            animateChild.addClass('ui-e-animated');
                            animateChild.addClass(animation);
                        },
                        offset: "90%"
                    });
                } else {
                    $el.css('opacity', 1);
                    setTimeout(function () {
                        el.removeClass('ui-e-' + animation);
                    }, 200);
                    animateChild.addClass('ui-e-animated');
                    animateChild.addClass(animation);
                }
                setTimeout(function () {
                    jQuery(_this3.$element).removeClass('elementor-invisible');
                }, 1);
            }
        }, {
            key: 'get_split',
            value: function get_split() {
                var asClass = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : true;

                var split = this.getElementSettings('ui_animate_split_by');

                if (!asClass) {
                    split = split === 'lines' ? 'words' : split;
                    return split.slice(0, -1);
                }
                return split;
            }
        }]);

        return SPLIT;
    }(elementorModules.frontend.handlers.Base);

    jQuery(window).on('elementor/frontend/init', function () {
        var addHandler = function addHandler($element) {
            elementorFrontend.elementsHandler.addHandler(SPLIT, { $element: $element });
        };
        elementorFrontend.hooks.addAction('frontend/element_ready/heading.default', addHandler);
        elementorFrontend.hooks.addAction('frontend/element_ready/text-editor.default', addHandler);
        elementorFrontend.hooks.addAction('frontend/element_ready/uicore-the-title.default', addHandler);
        elementorFrontend.hooks.addAction('frontend/element_ready/uicore-page-description.default', addHandler);
        elementorFrontend.hooks.addAction('frontend/element_ready/highlighted-text.default', addHandler);
    });
}, false);

/***/ }),

/***/ 444:
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),

/***/ 445:
/***/ (function(module, exports, __webpack_require__) {

"use strict";
var __WEBPACK_AMD_DEFINE_FACTORY__, __WEBPACK_AMD_DEFINE_RESULT__;

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

!function (n, t) {
  "object" == ( false ? "undefined" : _typeof(exports)) && "undefined" != typeof module ? module.exports = t() :  true ? !(__WEBPACK_AMD_DEFINE_FACTORY__ = (t),
				__WEBPACK_AMD_DEFINE_RESULT__ = (typeof __WEBPACK_AMD_DEFINE_FACTORY__ === 'function' ?
				(__WEBPACK_AMD_DEFINE_FACTORY__.call(exports, __webpack_require__, exports, module)) :
				__WEBPACK_AMD_DEFINE_FACTORY__),
				__WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__)) : n.Splitting = t();
}(undefined, function () {
  "use strict";

  var o = document,
      l = o.createTextNode.bind(o);
  function d(n, t, e) {
    n.style.setProperty(t, e);
  }function f(n, t) {
    return n.appendChild(t);
  }function p(n, t, e, r) {
    var i = o.createElement("span");
    return t && (i.className = t), e && (!r && i.setAttribute("data-" + t, e), i.textContent = e), n && f(n, i) || i;
  }function h(n, t) {
    return n.getAttribute("data-" + t);
  }function m(n, t) {
    return n && 0 != n.length ? n.nodeName ? [n] : [].slice.call(n[0].nodeName ? n : (t || o).querySelectorAll(n)) : [];
  }function u(n) {
    for (var t = []; n--;) {
      t[n] = [];
    }return t;
  }function v(n, t) {
    n && n.some(t);
  }function c(t) {
    return function (n) {
      return t[n];
    };
  }var a = {};
  function n(n, t, e, r) {
    return { by: n, depends: t, key: e, split: r };
  }function r(n) {
    return function t(e, n, r) {
      var i = r.indexOf(e);
      if (-1 == i) {
        r.unshift(e);
        var o = a[e];
        if (!o) throw new Error("plugin not loaded: " + e);
        v(o.depends, function (n) {
          t(n, e, r);
        });
      } else {
        var u = r.indexOf(n);
        r.splice(i, 1), r.splice(u, 0, e);
      }return r;
    }(n, 0, []).map(c(a));
  }function t(n) {
    a[n.by] = n;
  }function g(n, r, i, o, u) {
    n.normalize();
    var c = [],
        a = document.createDocumentFragment();
    o && c.push(n.previousSibling);
    var s = [];
    return m(n.childNodes).some(function (n) {
      /* Split images too*/
      if (n.nodeType === 1 && (n.classList.contains('ui-e-highlight-image') || n.classList.contains('ui-e-highlight-icon') || n.nodeName == 'IMG')) {
        c.push(n);console.log('yes');
      }
      /* Split images too*/
      if (!n.tagName || n.hasChildNodes()) {
        if (n.childNodes && n.childNodes.length) return s.push(n), void c.push.apply(c, g(n, r, i, o, u));
        var t = n.wholeText || "",
            e = t.trim();
        e.length && (" " === t[0] && s.push(l(" ")), v(e.split(i), function (n, t) {
          t && u && s.push(p(a, "whitespace", " ", u));
          var e = p(a, r, n);
          c.push(e), s.push(e);
        }), " " === t[t.length - 1] && s.push(l(" ")));
      } else s.push(n);
    }), v(s, function (n) {
      f(a, n);
    }), n.innerHTML = "", f(n, a), c;
  }var s = 0;
  var i = "words",
      e = n(i, s, "word", function (n) {
    return g(n, "word", /\s+/, 0, 1);
  }),
      y = "chars",
      w = n(y, [i], "char", function (n, e, t) {
    var r = [];
    return v(t[i], function (n, t) {
      r.push.apply(r, g(n, "char", "", e.whitespace && t));
    }), r;
  });
  function b(e) {
    var f = (e = e || {}).key;
    return m(e.target || "[data-splitting]").map(function (a) {
      var s = a["🍌"];
      if (!e.force && s) return s;
      s = a["🍌"] = { el: a };
      var n = e.by || h(a, "splitting");
      n && "true" != n || (n = y);
      var t = r(n),
          l = function (n, t) {
        for (var e in t) {
          n[e] = t[e];
        }return n;
      }({}, e);
      return v(t, function (n) {
        if (n.split) {
          var t = n.by,
              e = (f ? "-" + f : "") + n.key,
              r = n.split(a, l, s);
          e && (i = a, c = (u = "--" + e) + "-index", v(o = r, function (n, t) {
            Array.isArray(n) ? v(n, function (n) {
              d(n, c, t);
            }) : d(n, c, t);
          }), d(i, u + "-total", o.length)), s[t] = r, a.classList.add(t);
        }var i, o, u, c;
      }), a.classList.add("splitting"), s;
    });
  }function N(n, t, e) {
    var r = m(t.matching || n.children, n),
        i = {};
    return v(r, function (n) {
      var t = Math.round(n[e]);(i[t] || (i[t] = [])).push(n);
    }), Object.keys(i).map(Number).sort(x).map(c(i));
  }function x(n, t) {
    return n - t;
  }b.html = function (n) {
    var t = (n = n || {}).target = p();
    return t.innerHTML = n.content, b(n), t.outerHTML;
  }, b.add = t;
  var T = n("lines", [i], "line", function (n, t, e) {
    return N(n, { matching: e[i] }, "offsetTop");
  }),
      L = n("items", s, "item", function (n, t) {
    return m(t.matching || n.children, n);
  }),
      k = n("rows", s, "row", function (n, t) {
    return N(n, t, "offsetTop");
  }),
      A = n("cols", s, "col", function (n, t) {
    return N(n, t, "offsetLeft");
  }),
      C = n("grid", ["rows", "cols"]),
      M = "layout",
      S = n(M, s, s, function (n, t) {
    var e = t.rows = +(t.rows || h(n, "rows") || 1),
        r = t.columns = +(t.columns || h(n, "columns") || 1);
    if (t.image = t.image || h(n, "image") || n.currentSrc || n.src, t.image) {
      var i = m("img", n)[0];
      t.image = i && (i.currentSrc || i.src);
    }t.image && d(n, "background-image", "url(" + t.image + ")");
    for (var o = e * r, u = [], c = p(s, "cell-grid"); o--;) {
      var a = p(c, "cell");
      p(a, "cell-inner"), u.push(a);
    }return f(n, c), u;
  }),
      H = n("cellRows", [M], "row", function (n, t, e) {
    var r = t.rows,
        i = u(r);
    return v(e[M], function (n, t, e) {
      i[Math.floor(t / (e.length / r))].push(n);
    }), i;
  }),
      O = n("cellColumns", [M], "col", function (n, t, e) {
    var r = t.columns,
        i = u(r);
    return v(e[M], function (n, t) {
      i[t % r].push(n);
    }), i;
  }),
      j = n("cells", ["cellRows", "cellColumns"], "cell", function (n, t, e) {
    return e[M];
  });
  return t(e), t(w), t(T), t(L), t(k), t(A), t(C), t(S), t(H), t(O), t(j), b;
});

/***/ })

},[443]);